/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/Core","./library"],function(e,r){"use strict";var i=r.ExampleColor;var t={apiVersion:2};t.render=function(r,t){var o=e.getLibraryResourceBundle("route.test.commons");r.openStart("div",t);if(t.getColor()===i.Highlight){r.class("myLibPrefixExampleHighlight")}else{r.class("myLibPrefixExample")}r.openEnd();r.text(o.getText("ANY_TEXT")+": "+t.getText());r.close("div")};return t});