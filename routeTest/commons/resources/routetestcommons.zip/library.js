/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"route.test.commons",version:"1.0.0",dependencies:["sap.ui.core"],types:["route.test.commons.ExampleColor"],interfaces:[],controls:["route.test.commons.Example"],elements:[],noLibraryCSS:false});var e=route.test.commons;e.ExampleColor={Default:"Default",Highlight:"Highlight"};return e});