/*!
 * ${copyright}
 */
sap.ui.define(["./library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,t){"use strict";var o=e.ExampleColor;var a=r.extend("route.test.commons.Example",{metadata:{library:"route.test.commons",properties:{text:{type:"string",group:"Data",defaultValue:null},color:{type:"route.test.commons.ExampleColor",group:"Appearance",defaultValue:o.Default}},events:{press:{}}},renderer:t,onclick:function(){this.firePress()}});return a});